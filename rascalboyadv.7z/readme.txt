Technical documentation
-----------------------
Product name        : RascalBoy Advance
Current Version     : 1.3.0.0

Supported platforms : Windows 95/98/Me/XP + DirectX 7.0 or higher
                      Windows NT4/2000 (not tested but should work...)

Author              : Lino Maglione
Website             : http://spazioinwind.libero.it/linoma/rascalboy.html
E-mail              : linoma@gmail.com



Emulation status
----------------
- ARM7TDMI : 32-bit ARM CPU support (100%)
             16-bit THUMB CPU support (100%) 
- Real sync emulation for HBlanks and VBlanks 
- GFX Mode 0 
	* 16 colors support 
	* 256 colors support 
	* BG0/BG1/BG2/BG3 support 
	* 256x256 up to 512x512 tile maps support 
	* Default priorities support 
	* Horizontal/Vertical flipping support 
	* Horizontal/Vertical offset support 
	* FadeIn/FadeOut Effect support
	* Alpha-blending Effect support
        * Rotation/Zoom
	* Windows 0/1 support
- GFX Mode 1 
	* 16 colors support 
	* 256 colors support 
	* BG0/BG1/BG2/BG3 support 
	* 256x256 up to 512x512 tile maps support 
	* 128x128 up to 1024x1024 Rotation/Scaling Mode
	* Default priorities support 
	* Horizontal/Vertical flipping support 
	* Horizontal/Vertical offset support 
	* FadeIn/FadeOut Effect support
	* Alpha-blending Effect support
        * Rotation/Zoom
	* Windows 0/1 support
- GFX Mode 2
	* 256 colors support 
	* BG2/BG3 support 
	* 128x128 up to 1024x1024 Rotation/Scaling Mode
	* Default priorities support 
	* Horizontal/Vertical offset support 
	* FadeIn/FadeOut Effect support
	* Alpha-blending Effect support
        * Rotation/Zoom
	* Windows 0/1 support
- GFX Mode 3 
	* 32768 colors support 
	* Rotation/Zoom
	* Horizontal/Vertical Mosaic Effect support 
	* FadeIn/FadeOut Effect support
	* Alpha-blending Effect support
	* Windows 0/1 support
- GFX Mode 4 
	* 256 out of 32768 colors support 
	* Double buffering support 
	* Rotation/Zoom
	* Windows 0/1 support
	* Horizontal/Vertical Mosaic Effect support 
	* FadeIn/FadeOut Effect support
	* Alpha-blending Effect support
- GFX Mode 5 
	* 32768 colors support 
	* Double buffering support 
	* Horizontal/Vertical Mosaic Effect support 
	* Rotation/Zoom
- OAM support 
	* Horizontal/Vertical position 
	* Horizontal/Vertical flip 
	* 8x8 up to 64x64 sprite size support 
	* 1D/2D sprite display support 
        * Rotation/Zoom
	* FadeIn/FadeOut Effect support
	* Alpha-blending Effect support
	* Trasparent OBJ
	* Window OBJ

- 256 colors line-per-line palette support
- Full DMA support
- Most BIOS features (50% real)
- PCM Sound Emulation
- Timer Emulation
- System ROM support
- Hardware IO support
- Palette/Video/OAM RAM support
- Cartridge SRAM support
- HBL/VBL emulation
- Full Keypad support



Special features
----------------
- ARM CPU debugger (100%)
- THUMB CPU debugger (100%)
	* Step by step feature
        * Step over
        * Run to next instruction feature
        * Run to breakpoint address
        * Breakpoint Pass Count
        * Breakpoint Pass Condition (Register and flags)
        * Events message (Step over)
        * Break on Enter IRQ
        * Break on Exit IRQ
        * Break on SWI
        * Break on start DMA
	* Break on Write, Read and Modify memory.
	* Enable and disable visualizzation layers.
        - ARM CPU registers, VBL counter display, Flags Status
        - BG/Bitmap Palette (256 colors) display
        - OBJ/Objects Palette (256 colors) display
        - DMA register display
        - OBJ display
	- Background display
        - Memory browser
        - Edit memory
        - Rendering zoom x1, x2, x3
        - Pause & Reset emulation
        - Frameskip support
        - Keyboard/Joystick support
        - BIN/AGB/GBA/ZIP files support
        - Register Key support
	- Video filters Blur,Bilinear, Motion Blur,TV Mode and Trilinear.
	- Audio filters Echo,SuperBass and VUMeter.
	- Audio and Video filters plug-in.
	- SIO's plugin.


Acknowledgements (in no particular order)
-----------------------------------------
- GBADEV.ORG for all the useful things (docs, demos...)
- Gameboy Advance Technical Info - taken from no$gba version 1.3
- CowBite Virtual Hardware Specifications
- The Audio Advance BeLogic
- The Pern Project

